package main;
import java.sql.Connection;
import java.sql.DriverManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Connect {
private Connect() {
		
	}
	 public static Connection getConnection(){  
	        Connection con=null;  
	        Logger log=Logger.getLogger(Connect.class);
	        try{
	        	
	    		PropertyConfigurator.configure("log4j.properties");
	        	Class.forName("oracle.jdbc.driver.OracleDriver");
	            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");  
	        }catch(Exception e){
	        	log.fatal(e);
	        }  
	        return con;  
	    }  
}
