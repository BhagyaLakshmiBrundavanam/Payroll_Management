package com.payroll.bean;

public class PaymentsBean {
	private int pmtId;
	private int pmtAmount;
	private int empId;
	private String pmtDate;
	private String pmtDesc;
	public int getPmtId() {
		return pmtId;
	}
	public void setPmtId(int pmtId) {
		this.pmtId = pmtId;
	}
	public int getPmtAmount() {
		return pmtAmount;
	}
	public void setPmtAmount(int pmtAmount) {
		this.pmtAmount = pmtAmount;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getPmtDate() {
		return pmtDate;
	}
	public void setPmtDate(String pmtDate) {
		this.pmtDate = pmtDate;
	}
	public String getPmtDesc() {
		return pmtDesc;
	}
	public void setPmtDesc(String pmtDesc) {
		this.pmtDesc = pmtDesc;
	}

}
