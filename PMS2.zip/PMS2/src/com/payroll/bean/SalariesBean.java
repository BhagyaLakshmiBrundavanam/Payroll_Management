package com.payroll.bean;

public class SalariesBean {
	private int salId;
	private int empId;
	private String salDesc;
	private String salType;
	private int salAmount;
	private int salTotal;
	public int getSalId() {
		return salId;
	}
	public void setSalId(int salId) {
		this.salId = salId;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getSalDesc() {
		return salDesc;
	}
	public void setSalDesc(String salDesc) {
		this.salDesc = salDesc;
	}
	public String getSalType() {
		return salType;
	}
	public void setSalType(String salType) {
		this.salType = salType;
	}
	public int getSalAmount() {
		return salAmount;
	}
	public void setSalAmount(int salAmount) {
		this.salAmount = salAmount;
	}
	public int getSalTotal() {
		return salTotal;
	}
	public void setSalTotal(int salTotal) {
		this.salTotal = salTotal;
	}
	
}
