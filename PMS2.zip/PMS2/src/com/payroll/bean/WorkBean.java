package com.payroll.bean;

public class WorkBean {
	private int workId;
	private int wUid;
	private String workTitle;
	private String workType;
	private int workDays;
	public int getWorkId() {
		return workId;
	}
	public void setWorkId(int workId) {
		this.workId = workId;
	}
	public int getwUid() {
		return wUid;
	}
	public void setwUid(int wUid) {
		this.wUid = wUid;
	}
	public String getWorkTitle() {
		return workTitle;
	}
	public void setWorkTitle(String workTitle) {
		this.workTitle = workTitle;
	}
	public String getWorkType() {
		return workType;
	}
	public void setWorkType(String workType) {
		this.workType = workType;
	}
	public int getWorkDays() {
		return workDays;
	}
	public void setWorkDays(int workDays) {
		this.workDays = workDays;
	}
	
}
