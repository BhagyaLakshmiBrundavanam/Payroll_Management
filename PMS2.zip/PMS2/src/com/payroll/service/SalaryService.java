package com.payroll.service;

import java.util.List;

import com.payroll.bean.SalariesBean;
import com.payroll.dao.SalDao;

public class SalaryService {

	public int addSal(SalariesBean sal) {
		return SalDao.addSal(sal);
	}

	public List<SalariesBean> getAllSal() {
		return SalDao.getAllSal();
	}
	

}
