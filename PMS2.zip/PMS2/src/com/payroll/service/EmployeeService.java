package com.payroll.service;

import java.util.List;

import com.payroll.bean.UserBean;
import com.payroll.dao.EmpDao;

public class EmployeeService {
	public int save(UserBean e) {
		return EmpDao.save(e);
	}
	public int delete(int id)
	{
		return EmpDao.delete(id);
	}
	public int update(UserBean e) {
		 
		return EmpDao.update(e);
	}
	public UserBean getEmployeeById(int id) {
		return EmpDao.getEmployeeById(id);
	}
	 public List<UserBean> getAllUsers(){  
		 return EmpDao.getAllUsers();
	 }
}
