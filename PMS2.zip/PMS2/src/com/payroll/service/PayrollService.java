package com.payroll.service;

import java.util.List;

import com.payroll.bean.PayrollBean;
import com.payroll.dao.PayrollDao;

public class PayrollService {
	public int savePayroll(PayrollBean p) {
		return PayrollDao.savePayroll(p);
	}
	public List<PayrollBean> getAllPayrolls() {
		return PayrollDao.getAllPayrolls();
	}
	public PayrollBean getPayroll(int id) {
		return PayrollDao.getPayroll(id);
	}

}
