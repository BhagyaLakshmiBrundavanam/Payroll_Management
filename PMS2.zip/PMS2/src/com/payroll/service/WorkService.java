package com.payroll.service;

import java.util.List;

import com.payroll.bean.WorkBean;
import com.payroll.dao.WorkDao;

public class WorkService {
	public int saveWork(WorkBean wb) {
		
		return  WorkDao.saveWork(wb);
	}

	public List<WorkBean> getAllWp() {
		return WorkDao.getAllWp();
	}

	public int deleteWp(int id) {
		return WorkDao.deleteWp(id);
	}
}
