package com.payroll.service;

import java.util.List;

import com.payroll.bean.RolesBean;
import com.payroll.dao.RoleDao;

public class RoleService {

	public List<RolesBean> getAllRoles() {
		return RoleDao.getAllRoles();
	}

	public int saveRole(RolesBean r) {
		return RoleDao.saveRole(r);
	}

	public int deleteRole(int id) {
		return RoleDao.deleteRole(id);
	}

}
