package com.payroll.service;

import java.util.List;

import com.payroll.bean.PaymentsBean;
import com.payroll.dao.PaymentsDao;

public class PaymentService {

	public int savePayment(PaymentsBean pmt) {
		
		return PaymentsDao.savePayment(pmt);
	}

	public List<PaymentsBean> viewPayments() {

		return PaymentsDao.viewPayments();
	}

}
