package com.payroll.dao;
import java.util.*;
import java.util.Date;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.payroll.bean.UserBean;
import main.Connect;
import java.sql.*;
import java.text.SimpleDateFormat;  
public class EmpDao {  
	public static final String BASE_PATH="log4j.properties";
private EmpDao() {
		
	}


    public static int save(UserBean e){  
    	Logger log = Logger.getLogger(EmpDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
       int status=0;  
        try{  
            Connection con=Connect.getConnection();  
            PreparedStatement ps=con.prepareStatement("insert into User_cls values(seq_user.nextval,?,?,?,?,?,?,?)");  
            ps.setInt(1, e.getRoleId());
            ps.setString(2,e.getUserName());  
            ps.setString(3,e.getUserEmail());
            Date date1=new SimpleDateFormat("dd-mm-yyyy").parse(e.getDob()); 
            java.sql.Date sqlDate = new java.sql.Date(date1.getTime());
            ps.setDate(4, sqlDate);
            ps.setString(5,e.getAddress());
            ps.setLong(6,e.getPhone());  
            ps.setString(7,e.getPassword()); 
            ResultSet s=ps.executeQuery();
            if(s.next()) {
            	status = 1;
            }
              
            con.close();  
        }catch(Exception ex){
        	log.fatal(e);
        	}  
          
        return status;  
    }  
    public static int update(UserBean e){  
    	Logger log = Logger.getLogger(EmpDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
        int status=0;  
        try{  
            Connection con=Connect.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "update user_cls set urole=?,uname=?,uemail=?,udob=?,uaddrress=?,u_mobile=?,u_password=? where usr_id=?");  
            ps.setInt(1, e.getRoleId());
            ps.setString(2,e.getUserName());  
            ps.setString(3,e.getUserEmail());
            Date date1=new SimpleDateFormat("dd-mm-yyyy").parse(e.getDob()); 
            java.sql.Date sqlDate = new java.sql.Date(date1.getTime());
            ps.setDate(4, sqlDate);
            ps.setString(5,e.getAddress());
            ps.setLong(6,e.getPhone());  
            ps.setString(7,e.getPassword());
            ps.setInt(8, e.getUserId());  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception ex){log.fatal(ex);}  
          
        return status;  
    }  
    public static int delete(int id){  
    	Logger log = Logger.getLogger(EmpDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
        int status=0;  
        try{  
            Connection con=Connect.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from user_cls where usr_id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){log.fatal(e);}  
          
        return status;  
    }  
    public static UserBean getEmployeeById(int id){  
    	Logger log = Logger.getLogger(EmpDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
        UserBean e=new UserBean();  
          
        try{  
            Connection con=Connect.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from user_cls where usr_id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
            	 e.setUserId(rs.getInt(1));  
                 e.setRoleId(rs.getInt(2));  
                 e.setUserName(rs.getString(3));  
                 e.setUserEmail(rs.getString(4));
                 e.setDob((rs.getDate(5)).toString());
                 e.setAddress(rs.getString(6)); 
                 e.setPhone(rs.getLong(7));
                 e.setPassword(rs.getString(8));
            }  
            con.close();  
        }catch(Exception ex) {
        	log.fatal(e);
        }  
          
        return e;  
    }  
    public static List<UserBean> getAllUsers(){ 
    	Logger log = Logger.getLogger(EmpDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
        List<UserBean> list=new ArrayList<>();  
          
        try{  
            Connection con=Connect.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from user_cls");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                UserBean e=new UserBean();  
                e.setUserId(rs.getInt(1));  
                e.setRoleId(rs.getInt(2));  
                e.setUserName(rs.getString(3));  
                e.setUserEmail(rs.getString(4));
                e.setDob((rs.getDate(5)).toString());
                e.setAddress(rs.getString(6)); 
                e.setPhone(rs.getLong(7));
                e.setPassword(rs.getString(8));
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){log.fatal(e);}  
          
        return list;  
    }  
}  