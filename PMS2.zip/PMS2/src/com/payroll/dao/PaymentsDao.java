package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.payroll.bean.PaymentsBean;

import main.Connect;

public class PaymentsDao {
	public static final String BASE_PATH="log4j.properties";
	private PaymentsDao() {
		
	}
	public static int savePayment(PaymentsBean pmt) {
		int status=0;
		Logger log = Logger.getLogger(PaymentsDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
		
		try {
			Connection con = Connect.getConnection();
			PreparedStatement pt = con.prepareStatement("Insert into payments values(seq_pmt.nextval,?,?,?,?)");
			pt.setInt(1, pmt.getEmpId());
			pt.setString(2, pmt.getPmtDesc());
			Date dt = new SimpleDateFormat("mm-yy-yyyy").parse(pmt.getPmtDate()); 
            java.sql.Date date = new java.sql.Date(dt.getTime());
			pt.setDate(3,date);
			pt.setDouble(4, pmt.getPmtAmount());
			status = pt.executeUpdate();
		}catch(Exception e) {
			log.fatal(e);
		}
		return status;
	}

	public static List<PaymentsBean> viewPayments()  {
		Logger log = Logger.getLogger(PaymentsDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
		
		List<PaymentsBean> pl = new ArrayList<>();
		try {
			Connection con = Connect.getConnection();
			PreparedStatement pt = con.prepareStatement("select *from payments");
			ResultSet rs = pt.executeQuery();
			while(rs.next()) {
				PaymentsBean p = new PaymentsBean();
				p.setPmtId(rs.getInt(1));
				p.setEmpId(rs.getInt(2));
				p.setPmtDesc(rs.getString(3));
				p.setPmtDate(rs.getDate(4).toString());
				p.setPmtAmount(rs.getInt(5));
				pl.add(p);
			}
		}catch(Exception e) {
			log.fatal(e);
		}
		return pl;
	}
	
}
