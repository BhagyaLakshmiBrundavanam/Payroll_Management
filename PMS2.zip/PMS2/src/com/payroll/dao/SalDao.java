package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.payroll.bean.SalariesBean;

import main.Connect;

public class SalDao {
	private SalDao() {
		
	}
	public static int addSal(SalariesBean sal) {
		int status=0;
		int days ;
		int amount;
		Logger log = Logger.getLogger(SalDao.class);
    	PropertyConfigurator.configure("log4j.properties");
		
		try {
			Connection con = Connect.getConnection();
			PreparedStatement pt = con.prepareStatement("insert into salaries values(seq_sal.nextval,?,?,?,?,?)");
			pt.setInt(1, sal.getEmpId());
			pt.setString(2, sal.getSalType());
			pt.setString(3, sal.getSalDesc());
			PreparedStatement pt1 = con.prepareStatement("select w_days from workpoint where w_uid=?");
			pt1.setInt(1, sal.getEmpId());
			ResultSet rw = pt1.executeQuery();
			if(rw.next()) {
				days= rw.getInt(1);
			}
			else {
				return 0;
			}
			PreparedStatement pt2 = con.prepareStatement(" select sum(pmt_amount) from payments where pmt_uid=?");
			pt2.setInt(1, sal.getEmpId());
			ResultSet rp = pt2.executeQuery();
			if(rp.next()) {
				amount = rp.getInt(1);
			}
			else {
				return 0;
			} 
			amount/=30;
			sal.setSalAmount(amount*days);
			sal.setSalTotal(amount*days);
			pt.setInt(4,  (amount*days));
			pt.setInt(5,  (amount*days));
			ResultSet rs = pt.executeQuery();
			if(rs.next()) {
				status=1;
			}
		}catch(Exception e) {
			log.fatal(e);
		}
		return status;
	}

	public static List<SalariesBean> getAllSal() {
		Logger log = Logger.getLogger(SalDao.class);
    	PropertyConfigurator.configure("log4j.properties");
		
		List<SalariesBean> sl = new ArrayList<>();
		try {
			Connection con = Connect.getConnection();
			PreparedStatement pt = con.prepareStatement(" select *from salaries");
			ResultSet rs=pt.executeQuery();
			while(rs.next()) {
				SalariesBean s = new SalariesBean();
				s.setSalId(rs.getInt(1));
				s.setEmpId(rs.getInt(2));
				s.setSalDesc(rs.getString(3));
				s.setSalType(rs.getString(4));
				s.setSalAmount(rs.getInt(5));
				s.setSalTotal(rs.getInt(6));
				sl.add(s);
			}
			
		}catch(Exception e) {
			log.fatal(e);
		
		}
		return sl;
	}
		
}
