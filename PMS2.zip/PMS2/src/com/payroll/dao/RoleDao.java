package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.payroll.bean.RolesBean;

import main.Connect;

public class RoleDao {
	public static final String BASE_PATH="log4j.properties";
private RoleDao() {
		
	}
	 public static int saveRole(RolesBean r){  
		 Logger log = Logger.getLogger(RoleDao.class);
	    	PropertyConfigurator.configure(BASE_PATH);
			
	       int status=0;  
	        try{  
	            Connection con=Connect.getConnection();  
	            PreparedStatement ps=con.prepareStatement(  
	                         "insert into Role values(seq_role.nextval,?,?)");  
	            ps.setString(1,r.getTitle());  
	            ps.setString(2,r.getDescription());
	            ResultSet s=ps.executeQuery();
	            if(s.next()) {
	            	status = 1;
	            }
	            con.close();  
	        }catch(Exception ex){log.fatal(ex);}  
	          
	        return status;  
	    }
	public static List<RolesBean> getAllRoles() {
		Logger log = Logger.getLogger(RoleDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
		
		 List<RolesBean> rl = new ArrayList<>();
		try {
			Connection con = Connect.getConnection();	
			PreparedStatement ps=con.prepareStatement("select * from Role");  
	            ResultSet rs=ps.executeQuery(); 
	           
	            while(rs.next()) {
	            	RolesBean r = new RolesBean();
	            	r.setId(rs.getInt(1));
	            	r.setTitle(rs.getString(2));
	            	r.setDescription(rs.getString(3));
	            	rl.add(r);
	            }
		}catch(Exception e) {
		log.fatal(e);
		
		
		} 
		return rl;
	}
	 public static int deleteRole(int id){  
		 Logger log = Logger.getLogger(RoleDao.class);
	    	PropertyConfigurator.configure(BASE_PATH);
			
	        int status=0;  
	        try{  
	            Connection con=Connect.getConnection();  
	            PreparedStatement ps=con.prepareStatement("delete from Role where role_id=?");  
	            ps.setInt(1,id);  
	            status=ps.executeUpdate();  
	              
	            con.close();  
	        }catch(Exception e){log.fatal(e);}  
	          
	        return status;  
	    }  
}
