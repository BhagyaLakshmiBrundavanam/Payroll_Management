package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.payroll.bean.WorkBean;

import main.Connect;

public class WorkDao {
	public static final String BASE_PATH="log4j.properties";
	private WorkDao() {
		
	}

	public static int saveWork(WorkBean w) {
		Logger log = Logger.getLogger(WorkDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
		int status=0;
		try {
			Connection con = Connect.getConnection();
			PreparedStatement pt = con.prepareStatement("insert into workpoint values(seq_wpt.nextval,?,?,?,?)");
			pt.setInt(1, w.getwUid());
			pt.setString(2, w.getWorkTitle());
			pt.setInt(3, w.getWorkDays());
			pt.setString(4, w.getWorkType());
			 ResultSet s=pt.executeQuery();
	            if(s.next()) {
	            	status = 1;
	            }
		}
		catch(Exception e) {
			log.fatal(e);
		}
		return status;
	}
	public static List<WorkBean> getAllWp(){
		Logger log = Logger.getLogger(WorkDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
		List<WorkBean> wl = new ArrayList<>();
		try {
			Connection con = Connect.getConnection();
			PreparedStatement pt = con.prepareStatement("select *from workpoint");
			ResultSet rs = pt.executeQuery();
			
 			while(rs.next()) {
				WorkBean w = new WorkBean();
				w.setWorkId(rs.getInt(1));
				w.setwUid(rs.getInt(2));
				w.setWorkTitle(rs.getString(3));
				w.setWorkDays(rs.getInt(4));
				w.setWorkType(rs.getString(5));
				wl.add(w);
			}
		}catch(Exception e) {
			log.fatal(e);
		}
		return wl;
	}
	public static int deleteWp(int id) {
		Logger log = Logger.getLogger(WorkDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
		int status=0;  
        try{  
            Connection con=Connect.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from workpoint where wid=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){
        	log.fatal(e);
        	}  
          
        return status;  
    
	}

}
