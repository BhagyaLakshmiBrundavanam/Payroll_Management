package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.payroll.bean.PayrollBean;
import main.Connect;

public class PayrollDao {
	public static final String BASE_PATH="log4j.properties";
	private PayrollDao() {
		
	}

	public static int savePayroll(PayrollBean p) {
		Logger log = Logger.getLogger(PayrollDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
		int status=0;
		try {
			Connection con = Connect.getConnection();
			PreparedStatement pt = con.prepareStatement("insert into payroll values(seq_prl.nextval,?,?,?,?)");
			pt.setInt(1, p.getEmpId());
			PreparedStatement pt1 = con.prepareStatement("select pmt_desc,pmt_amount from payments where pmt_uid=?");
			pt1.setInt(1, p.getEmpId());
			ResultSet rs  = pt1.executeQuery();	
			String pyd= "";
			int sum=0;
			while(rs.next()) {
				pyd = rs.getString(1)+":"+rs.getInt(2)+"";
				sum += rs.getInt(2);
			}
			pyd += "Total: "+sum;
			p.setPayDesc(pyd);
			p.setPayTitle("Payroll");
			pt.setString(2, p.getPayTitle());
			pt.setString(3, p.getPayDesc());
			pt.setString(4,p.getPayType());
			ResultSet rs1 = pt.executeQuery();
			if(rs1.next()) {
				status=1;
			}
			
		}catch(Exception e) {
			log.fatal(e);
		}
		return status;
	}

	public static List<PayrollBean> getAllPayrolls() {
		Logger log = Logger.getLogger(PayrollDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
		List<PayrollBean> pl = new ArrayList<>();
		try {
			Connection con = Connect.getConnection();
			PreparedStatement ps = con.prepareStatement("select *from payroll");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				PayrollBean p = new PayrollBean();
				p.setPayId(rs.getInt(1));
				p.setEmpId(rs.getInt(2));
				p.setPayTitle(rs.getString(3));
				p.setPayDesc(rs.getString(4));
				p.setPayType(rs.getString(5));
				pl.add(p);
			}
		}catch(Exception e) {
			log.fatal(e);
		}
		return pl;
	}

	public static PayrollBean getPayroll(int id) {
		Logger log = Logger.getLogger(PayrollDao.class);
    	PropertyConfigurator.configure(BASE_PATH);
		PayrollBean p = new PayrollBean();
		try {
			Connection con = Connect.getConnection();
			PreparedStatement ps = con.prepareStatement("select *from payroll where pay_uid=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				p.setPayId(rs.getInt(1));
				p.setEmpId(rs.getInt(2));
				p.setPayTitle(rs.getString(3));
				p.setPayDesc(rs.getString(4));
				p.setPayType(rs.getString(5));
			}
		}catch(Exception e) {
			log.fatal(e);
		}
		return p;
	}

}
