package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.payroll.bean.RolesBean;
import com.payroll.service.RoleService;
@WebServlet("/ViewRole")
public class ViewRole extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out=response.getWriter();  
	        out.println("<h1>Roles List</h1>");  
	          RoleService rs = new RoleService();
	        List<RolesBean> list=rs.getAllRoles();  
	        out.print("<table border='1' width='100%'"); 
	        out.println("<thead style='color:black;background-color:#FFF0F5;'>");
	        out.print("<tr><th>Role_id</th><th>Role_title</th><th>Role Discription</th><th>Edit</th><th>Delete</th></tr>");  
	        out.println("</thead>");
	        out.println("<tbody style='color:black;background-color:#D3D3D3;'>");
	        for(RolesBean r:list){  
	         out.print("<tr><td>"+r.getId()+"</td><td>"+r.getTitle()+"</td><td>"+r.getDescription()+"</td><td><a href='EditRole?id="+r.getId()+"'>edit</a></td><td><a href='DeleteRole?id="+r.getId()+"'>delete</a></td></tr>");  
	        }  
	        out.print("</tbody></table>");  
	}

}
