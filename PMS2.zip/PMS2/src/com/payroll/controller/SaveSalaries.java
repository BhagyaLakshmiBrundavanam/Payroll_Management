package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.bean.SalariesBean;
import com.payroll.service.SalaryService;

@WebServlet("/SaveSalaries")
public class SaveSalaries extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw  = response.getWriter();
		int salUid = Integer.parseInt(request.getParameter("sal_uid"));
		String salType = request.getParameter("sal_type");
		String salDesc = request.getParameter("sal_desc");
		SalariesBean sal = new SalariesBean();
		sal.setEmpId(salUid);
		sal.setSalType(salType);
		sal.setSalDesc(salDesc);
		SalaryService ss = new SalaryService();
		if(ss.addSal(sal)>0) {
			pw.println("Salary record saved successfully..");
		}else {
			pw.println("Salary record failed");
		}
	}

}
