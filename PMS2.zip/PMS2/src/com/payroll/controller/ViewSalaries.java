package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.payroll.bean.SalariesBean;
import com.payroll.service.SalaryService;
@WebServlet("/ViewSalaries")
public class ViewSalaries extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<SalariesBean> sl;
		String td = "</td><td>";
		SalaryService ss = new SalaryService();
		sl = ss.getAllSal();
		PrintWriter pw = response.getWriter();
		pw.println("<h1 color='red'>Salaries Data<h1>");
		pw.println("<table border='1' width='100%'");
		pw.println("<thead style='color:black;background-color:#FFF0F5;'>");
		pw.println("<tr><th>Salary id</th><th>Employee id</th><th>Salary Description</th><th>Salary Type</th><th>Salary Amount</th><th>Salary total</th></tr>");
		pw.println("</thead>");
		pw.println("<tbody style='color:black;background-color:#D3D3D3;'>");
		for(SalariesBean s:sl) {
			pw.print("<tr><td>"+s.getSalId()+td+s.getEmpId()+td+s.getSalDesc()+td+s.getSalType()+td+s.getSalAmount()+td+s.getSalTotal()+"</td></tr>");  
		}
		pw.print("</tbody></table>"); 
	}

}
