package com.payroll.controller;
import java.io.IOException;
import java.io.PrintWriter;
 import javax.servlet.ServletException;
 import javax.servlet.annotation.WebServlet;
 import javax.servlet.http.HttpServlet;
  import javax.servlet.http.HttpServletRequest;
  import javax.servlet.http.HttpServletResponse; 
  import javax.servlet.http.HttpSession;

import com.payroll.bean.UserBean;
import com.payroll.service.EmployeeService;
  
  @WebServlet("/ViewProfile")
  public class ViewProfile extends HttpServlet {
	  @Override
	  protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  String tdr = "</td><tr>";
		  response.getWriter().println("<h1>Employee Profile</h1>");
		  HttpSession ses = request.getSession(); 
		  String name = (String) ses.getAttribute("uname");
		  response.getWriter().println(name);
		  int id = (int) ses.getAttribute("uid");
		  ses.setAttribute("uid", id);
		  EmployeeService es = new EmployeeService();
		  UserBean u = es.getEmployeeById(id);
		  PrintWriter pw = response.getWriter();
		  pw.println("<table border='1' width='100%'");
		  pw.println("<thead style='color:black;background-color:#FFF0F5;'>");
		  pw.println("<tr><th>Employee Id</th><td>"+u.getUserId()+tdr);
		  pw.println("<tr><th>Employee Name</th><td>"+u.getUserName()+tdr);
		  pw.println("<tr><th>Employee Role id</th><td>"+u.getRoleId()+tdr);
		  pw.println("<tr><th>Employee Email</th><td>"+u.getUserEmail()+tdr);
		  pw.println("<tr><th>Employee Date of Birth</th><td>"+u.getDob()+tdr);
		  pw.println("<tr><th>Employee Address</th><td>"+u.getAddress()+tdr);
		  pw.println("<tr><th>Employee mobile number</th><td>"+u.getPhone()+ tdr);
		  pw.println("<tr><th>Employee password</th><td>"+u.getPassword()+tdr);
		  pw.println("<tr><th colspan='2'><a href='EditProfile.jsp?id="+u.getUserId()+"'>edit</a></th></tr>"); 
		  pw.println("</thead>");
		  pw.println("</table>"); 
	  }
  
 }
 