package com.payroll.controller;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;
import com.payroll.service.EmployeeService;  
@WebServlet("/DeleteEmployee")  
public class DeleteEmployee extends HttpServlet { 
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
             throws ServletException, IOException {   
    	EmployeeService es = new EmployeeService();
        int status=  es.delete(Integer.parseInt(request.getParameter("id")));  
        PrintWriter pw = response.getWriter();
        if(status>0) {
        	pw.print("deleted Succee");
        	RequestDispatcher rd=request.getRequestDispatcher("ViewData");  
	        rd.forward(request, response);  
        }else {
        	pw.print("deleted failed..please check all the dependent databses ..");
        	RequestDispatcher rd=request.getRequestDispatcher("/ViewData");  
	        rd.include(request, response);  
        }
       
    }  
}  