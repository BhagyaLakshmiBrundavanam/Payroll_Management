package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.bean.PayrollBean;
import com.payroll.service.PayrollService;

/**
 * Servlet implementation class SavePayroll
 */
@WebServlet("/SavePayroll")
public class SavePayroll extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw  = response.getWriter();
		int payUid = Integer.parseInt(request.getParameter("pay_uid"));
		String payType = request.getParameter("pay_type");
		PayrollBean p = new PayrollBean();
		p.setEmpId(payUid);
		p.setPayType(payType);
		PayrollService ps  =new PayrollService();
		if(ps.savePayroll(p)>0) {
			pw.println("Payroll added success..");
		}else {
			pw.print("Failed..");
		}
	}

}
