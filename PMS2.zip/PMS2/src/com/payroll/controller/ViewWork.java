package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.bean.WorkBean;
import com.payroll.service.WorkService;
@WebServlet("/ViewWork")
public class ViewWork extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out=response.getWriter();  
		 String td = "</td><td>";
	        out.println("<h1>Workpoints List</h1>");  
	        WorkService ws = new WorkService();
	          List<WorkBean> wl = ws.getAllWp();
	          out.print("<table border='1' width='100%'");  
	          out.println("<thead style='color:black;background-color:#FFF0F5;'>");
	          out.print("<tr><th>Work_id</th><th>Employee_id</th><th>Work_title</th><th>Working Days</th><th>Work_Type</th><th>Edit</th><th>Delete</th></tr>");  
	          out.println("</thead>"); 
	          out.println("<tbody style='color:black;background-color:#D3D3D3;'>");
	          for(WorkBean w:wl) {
	        	   out.print("<tr><td>"+w.getWorkId()+td+w.getwUid()+td+w.getWorkTitle()+td+w.getWorkDays()+td+w.getWorkType()+"</td><td><a href='EditWp?id="+w.getWorkId()+"'>edit</a></td><td><a href='DeleteWp?id="+w.getWorkId()+"'>delete</a></td></tr>");  
	     	      
	          }
	          out.print("</tbody></table>"); 
	}

}
