package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.payroll.bean.PayrollBean;
import com.payroll.service.PayrollService;
@WebServlet("/ViewPayroll")
public class ViewPayroll extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String td = "</td><td>";
		HttpSession ses = request.getSession();
		PrintWriter pw = response.getWriter();
		PayrollService ps = new PayrollService();
		if(ses.getAttribute("uid")==null) {
			List<PayrollBean> pl;
			pl = ps.getAllPayrolls();
			pw.println("<h1>Payments Data<h1>");
			pw.println("<table border='1' width='100%'");
			pw.println("<thead style='color:black;background-color:#FFF0F5;'>");
			pw.println("<tr><th>Payroll id</th><th>Employee id</th><th>Payroll Title</th><th>payroll Discription</th><th>payroll type</th></tr>");
			pw.println("</thead>");
			pw.println("<tbody style='color:black;background-color:#f0f0f0;'>");
			for(PayrollBean p:pl) {
				pw.println("<tr><td>"+p.getPayId()+td+p.getEmpId()+td+p.getPayTitle()+td+p.getPayDesc()+td+p.getPayType()+"</td></tr>");
			}
			pw.println("</tbody></table>");
		}else {
			PayrollBean p =ps.getPayroll((int)ses.getAttribute("uid"));
			pw.println("<h1>Payments Data<h1>");
			pw.println("<table border='1' width='100%'");
			pw.println("<thead style='color:black;background-color:#FFF0F5;'>");
			pw.println("<tr><th>Payroll id</th><th>Employee id</th><th>Payroll Title</th><th>payroll Discription</th><th>payroll type</th></tr>");
			pw.println("</thead>");
			pw.println("<tbody style='color:black;background-color:#f0f0f0;'>");
				pw.println("<tr><td>"+p.getPayId()+td+p.getEmpId()+td+p.getPayTitle()+td+p.getPayDesc()+td+p.getPayType()+"</td></tr>");
			pw.println("</tbody></table>");
			pw.print("<button onclick='window.print()'>Print</button>");
		}
			
		
		
	}
}