package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.payroll.service.RoleService;

@WebServlet("/DeleteRole")
public class DeleteRole extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id  = Integer.parseInt(request.getParameter("id"));
		PrintWriter pw  = response.getWriter();
		RoleService rs = new RoleService();
		if(rs.deleteRole(id)>0) {
			pw.print("deleted Succee");
			RequestDispatcher rd=request.getRequestDispatcher("/ViewRole");  
	        rd.forward(request, response);     
       }else {
       	pw.print("delete failed..");
       	RequestDispatcher rd=request.getRequestDispatcher("/ViewRole");  
        rd.include(request, response);  
       }
	}

}
