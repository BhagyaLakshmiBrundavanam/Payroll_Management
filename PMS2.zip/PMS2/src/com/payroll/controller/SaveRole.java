package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.bean.RolesBean;
import com.payroll.service.RoleService;




@WebServlet("/SaveRole")
public class SaveRole extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");  
	        PrintWriter out=response.getWriter();  
	        String roletitle = request.getParameter("rtitle");
	        String roledisc = request.getParameter("rdisc");
	        RolesBean r  = new RolesBean();
	        r.setTitle(roletitle);
	        r.setDescription(roledisc);
	        RoleService rs = new RoleService();
	        int status=rs.saveRole(r);  
	        if(status>0){  
	            out.print("<p>Record saved successfully!</p>");  
	            request.getRequestDispatcher("/viewData").include(request, response);  
	        }else{  
	            out.println("Sorry! unable to save record");  
	        }  
	}

}
