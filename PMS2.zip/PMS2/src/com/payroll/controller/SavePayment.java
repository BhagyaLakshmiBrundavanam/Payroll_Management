package com.payroll.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.bean.PaymentsBean;
import com.payroll.service.PaymentService;

@WebServlet("/SavePayment")
public class SavePayment extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 int pmtUid = Integer.parseInt(request.getParameter("pmt_uid"));  
	        String pmtDesc=request.getParameter("pmt_desc");  
	        String pmtDate=request.getParameter("pmt_date");   
	        int pmtAmount =Integer.parseInt(request.getParameter("pmt_amount")); 
	        PaymentsBean pmt = new PaymentsBean();
	        pmt.setEmpId(pmtUid);
	        pmt.setPmtAmount(pmtAmount);
	        pmt.setPmtDesc(pmtDesc);
	        pmt.setPmtDate(pmtDate);
	        PaymentService ps = new PaymentService();
	        if(ps.savePayment(pmt)>0) {
	        	response.getWriter().println("Insertion success..");
	        	RequestDispatcher rd=request.getRequestDispatcher("/ViewPayments");  
		        rd.include(request, response);  
	        }else {
	        	response.getWriter().println("Insertion Failed..");
	        	RequestDispatcher rd=request.getRequestDispatcher("/SavePayments.jsp");  
		        rd.include(request, response);  
	        }
	        
	}

}
