package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.payroll.bean.UserBean;
import com.payroll.service.EmployeeService;

@WebServlet("/EditEmployee")
public class EditEmployee extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		Logger log = Logger.getLogger(EditEmployee.class);
		PropertyConfigurator.configure("log4j.properties");
		try {
			 PrintWriter out=response.getWriter();  
		
	        int userid = Integer.parseInt((String) request.getSession().getAttribute("uid"));  
	        String username=request.getParameter("username");  
	        String password=request.getParameter("userpass");  
	        String useremail=request.getParameter("email");  
	        String address=request.getParameter("useraddr");  
	        String dob = request.getParameter("userdob"); 
	        int roleId = Integer.parseInt(request.getParameter("uroleid"));
	        Long phone =  (long) Integer.parseInt(request.getParameter("usermobile"));
	        UserBean u=new UserBean();  
	        u.setUserName(username);  
	        u.setUserId(userid);
	        u.setUserEmail(useremail);
	        u.setPassword(password);  
	        u.setAddress(address);  
	        u.setDob(dob);
	        u.setRoleId(roleId);
	        u.setPhone(phone); 
	        EmployeeService es = new EmployeeService();
	        int status=es.update(u);  
	        if(status>0){  
	            out.print("<p>Record updated successfully!</p>");  
	            request.getRequestDispatcher("/ViewData").include(request, response);  
	        }else{  
	            out.println("Sorry! unable to save record");  
	            RequestDispatcher rd=request.getRequestDispatcher("/ViewData");  
		        rd.include(request, response);  
	        }  
	        out.close(); 
		}catch(Exception e) {
			log.fatal(e);
		}
        
	}

}