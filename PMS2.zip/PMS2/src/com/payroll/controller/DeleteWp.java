package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.payroll.service.WorkService;

/**
 * Servlet implementation class DeleteWp
 */
@WebServlet("/DeleteWp")
public class DeleteWp extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id  = Integer.parseInt(request.getParameter("id"));
		PrintWriter pw  = response.getWriter();
		WorkService ws = new WorkService();
		if(ws.deleteWp(id)>0) {
			pw.print("deleted Succee");
			RequestDispatcher rd=request.getRequestDispatcher("ViewWork");  
	        rd.forward(request, response);  
       }else {
       	pw.print("delete failed..");
       	RequestDispatcher rd=request.getRequestDispatcher("/ViewWork");  
        rd.include(request, response);  
       }
	}

}
