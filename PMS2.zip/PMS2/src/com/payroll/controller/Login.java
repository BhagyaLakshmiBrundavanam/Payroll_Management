package com.payroll.controller;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import main.Connect;

@WebServlet("/Login")
public class Login extends HttpServlet {
	Connection conn;
	@Override
	public void init(ServletConfig config) throws ServletException  {
		conn = Connect.getConnection();
		
		
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger log = Logger.getLogger(Login.class);
		PropertyConfigurator.configure("log4j.properties");
		int loginas = Integer.parseInt(request.getParameter("Loginas"));
		String username = request.getParameter("user_name");
		String password = request.getParameter("password");
		HttpSession se ;
		try {
			if(loginas/100!=4) {
				PreparedStatement pt = conn.prepareStatement("select *from User_cls where  uname=? and u_password=? and urole=?");
				pt.setString(1, username);
				pt.setString(2, password);
				pt.setInt(3, loginas);
				ResultSet rs = pt.executeQuery(); 
				if(rs.next()) {	
					switch(loginas/100) {
						case 1:se = request.getSession();
						se.setAttribute("Admin",rs.getString(3));
								response.sendRedirect("Admin.jsp");
								break;
						case 2: se = request.getSession();
								se.setAttribute("Manager",rs.getString(3));
								response.sendRedirect("Manager.jsp");break;
						case 3:se = request.getSession();
								se.setAttribute("Account",rs.getString(3));
								response.sendRedirect("Account.jsp");break;
						default:break;
					}
				}else {
					response.getWriter().println("<h1>Login failed..please try again.</h1>");
					RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
			        rd.include(request, response);  
					log.info("Login failed");
					
				}
				
			}else {
				PreparedStatement pt1 = conn.prepareStatement("select *from User_cls where  uname=? and u_password=?");
				pt1.setString(1, username);
				pt1.setString(2, password);
				ResultSet rs1= pt1.executeQuery(); 
				if(rs1.next()) {	
						se = request.getSession();
						se.setAttribute("uid", rs1.getInt(1));
						se.setAttribute("Employee",rs1.getString(3));
						response.sendRedirect("EmployeeLog.jsp");
			
				}else {
					response.getWriter().println("<h1>Login failed..please try again.</h1>");
					RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
			        rd.include(request, response);  
					log.info("Login failed");
				}
			
			}
		} catch (Exception e) {	
			log.fatal(e);
		}
		
		
			
	}

}
