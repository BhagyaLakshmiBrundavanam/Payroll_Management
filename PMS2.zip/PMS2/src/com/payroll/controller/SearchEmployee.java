package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.bean.UserBean;
import com.payroll.service.EmployeeService;

@WebServlet("/SearchEmployee")
public class SearchEmployee extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String td = "</td><td>";
		EmployeeService es = new EmployeeService();
		PrintWriter out = response.getWriter();
		UserBean e = es.getEmployeeById(id);
		  out.print("<table border='1' width='100%'");  
	        out.print("<tr><th>Id</th><th>Name</th><th>Password</th><th>Email</th><th>Country</th><th>Edit</th><th>Delete</th></tr>");   
	         out.print("<tr><td>"+e.getUserId()+td+e.getUserName()+td+e.getPassword()+td+e.getUserEmail()+td+e.getAddress()+"</td><td><a href='EditEmp.jsp?id="+e.getUserId()+"'>edit</a></td><td><a href='deleteEmployee?id="+e.getUserId()+"'>delete</a></td></tr>");    
	        out.print("</table>");  
		
		
	
	}

}
