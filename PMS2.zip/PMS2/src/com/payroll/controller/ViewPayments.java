package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.bean.PaymentsBean;
import com.payroll.service.PaymentService;

@WebServlet("/ViewPayments")
public class ViewPayments extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<PaymentsBean> pl ;
		String td = "</td><td>";
		PaymentService ps = new PaymentService();
		pl=ps.viewPayments();
		PrintWriter pw = response.getWriter();
		pw.println("<h1>Payments Data<h1>");
		pw.println("<table border='1' width='100%'");
		pw.println("<thead style='color:black;background-color:#FFEFD5;'>");
		pw.println("<tr><th>payment id</th><th>Employee id</th><th>Payment Description</th><th>payment date</th><th>Payment amount</th></tr>");
		pw.println("</thead>");
		pw.println("<tbody style='color:black;background-color:#ADD8E6;'>");
		for(PaymentsBean p:pl) {
			pw.print("<tr><td>"+p.getPmtId()+td+p.getEmpId()+td+p.getPmtDesc()+td+p.getPmtDate()+td+p.getPmtAmount()+"</td></tr>");  
		}
		pw.println("</tbody></table>");
	}

}
