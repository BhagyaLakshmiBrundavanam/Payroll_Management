package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.payroll.bean.WorkBean;
import com.payroll.service.WorkService;
@WebServlet("/SaveWorkpoint")
public class SaveWorkpoint extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");  
		 Logger log = Logger.getLogger(SaveWorkpoint.class);
	    	PropertyConfigurator.configure("log4j.properties");
			
	       try {
	    	   PrintWriter out=response.getWriter();  
		        int wUid = Integer.parseInt(request.getParameter("w_uid"));
		        String wTitle=request.getParameter("wtitle");  
		       int wDays=Integer.parseInt(request.getParameter("wdays"));  
		        String wType=request.getParameter("wtype"); 
		        WorkBean w = new WorkBean();
		        w.setwUid(wUid);
		        w.setWorkTitle(wTitle);
		       w.setWorkDays(wDays);
		       w.setWorkType(wType);
		       WorkService ws = new WorkService();
		       int status  = ws.saveWork(w);
		       if(status>0) {
		    	   out.println("Insertion succesfull");
		    	   RequestDispatcher rd=request.getRequestDispatcher("ViewWork");  
			        rd.forward(request, response);  
		       }else {
		    	   out.println("Sorry..Insertion failed");
		    	   RequestDispatcher rd=request.getRequestDispatcher("/SaveWorkpoint.jsp");  
			        rd.include(request, response);  
		       }
	       }catch(Exception e) {
	    	   log.fatal(e);
	       }
	}

}
